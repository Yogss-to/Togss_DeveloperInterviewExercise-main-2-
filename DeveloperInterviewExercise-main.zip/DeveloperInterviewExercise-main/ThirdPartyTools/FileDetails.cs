﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace ThirdPartyTools
{
    public class FileDetails
    {
        private readonly Random _random = new Random();

        public string Version(string filePath)
        {
           // return string.Format("{0}.{1}.{2}", _random.Next(5), _random.Next(8), _random.Next(22));
            var versionInfo = FileVersionInfo.GetVersionInfo(filePath);
            string version = versionInfo.FileVersion;
            return version;
        }

        public int Size(string filePath)
        {
            //return _random.Next(100000) + 1000000;

            FileInfo fi = new FileInfo(filePath);

            // Create a new file   
            using (FileStream fs = fi.Create())
            {
                Byte[] txt = new UTF8Encoding(true).GetBytes("New file.");
                fs.Write(txt, 0, txt.Length);
                Byte[] author = new UTF8Encoding(true).GetBytes("Author Mahesh Chand");
                fs.Write(author, 0, author.Length);
            }
            return (int)fi.Length;
        }
    }
}

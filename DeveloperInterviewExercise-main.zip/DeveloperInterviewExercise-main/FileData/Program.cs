﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {

            
            Console.WriteLine("Please provide fileDetails ");
            Console.Read();
            //Console.WriteLine("Please provide filePath ");
            //Console.Read();
            string str = Console.ReadLine();
            var getDetails = new GetFileDetails();
             var filePath = "C://Users//yogeshwari.torawane//Downloads//DeveloperInterviewExercise-main//DeveloperInterviewExercise-main//FileData.sln";
       
            var version= getDetails.GetDetails(str,filePath);
            var size = getDetails.GetSize(str,filePath);
          
            Console.WriteLine("version of file : " + version);
            Console.WriteLine("Size of file : " + size);

           
        }

          }


    public class GetFileDetails
    {
        public string GetDetails(string arg, string filePath)
        {
            string str= null;
            if (arg == "-v" || arg == "--v" || arg == "/v" || arg == "--version")
            {
                var filename = new FileDetails();
                str = filename.Version(filePath);
                return str;
            }
                          
            return str;
        }

        public int GetSize(string arg,string filePath)
        {
           int fileSize = 0;
           if (arg == "-s" || arg == "--s" || arg == "/s" || arg == "--size")
            {
                var filename = new FileDetails();
                 fileSize = filename.Size(filePath);
                return fileSize;
            }
            return fileSize;
        }



    }
}
